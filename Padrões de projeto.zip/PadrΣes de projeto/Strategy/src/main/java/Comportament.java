public interface Comportament {
    void mover();
}
